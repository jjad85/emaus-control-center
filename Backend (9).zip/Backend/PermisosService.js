/**
 * ============================================================
 * PERMISOS SERVICE
 * ============================================================
 *
 * Obtiene los permisos por rol desde la hoja PermisosRol.
 *
 * Estructura esperada:
 * Rol | Permiso | Activo
 */

const CLAVE_CACHE_PERMISOS_ROL =
  'EMAUS_PERMISOS_ROL_V1';

const DURACION_CACHE_PERMISOS_SEGUNDOS =
  300;

/**
 * Obtiene la matriz completa de permisos.
 *
 * Ejemplo:
 * {
 *   administrador: [
 *     'REGISTRAR_CAMINANTE',
 *     'EDITAR_CAMINANTE'
 *   ],
 *   tesoreria: [
 *     'ACTUALIZAR_PAGO'
 *   ]
 * }
 */
function obtenerMatrizPermisos() {
  const cache =
    CacheService.getScriptCache();

  const valorCache =
    cache.get(
      CLAVE_CACHE_PERMISOS_ROL
    );

  if (valorCache) {
    try {
      return JSON.parse(
        valorCache
      );
    } catch (error) {
      cache.remove(
        CLAVE_CACHE_PERMISOS_ROL
      );
    }
  }

  const filas =
    leerHojaComoObjetos(
      HOJAS.PERMISOS_ROL
    );

  const matriz = {};

  filas.forEach(
    function(registro) {
      if (
        !convertirBooleano(
          registro.activo
        )
      ) {
        return;
      }

      const rol =
        normalizarTexto(
          registro.rol
        );

      const permiso =
        normalizarPermiso(
          registro.permiso
        );

      if (!rol || !permiso) {
        return;
      }

      if (!matriz[rol]) {
        matriz[rol] = [];
      }

      if (
        !matriz[rol].includes(
          permiso
        )
      ) {
        matriz[rol].push(
          permiso
        );
      }
    }
  );

  cache.put(
    CLAVE_CACHE_PERMISOS_ROL,
    JSON.stringify(matriz),
    DURACION_CACHE_PERMISOS_SEGUNDOS
  );

  return matriz;
}

/**
 * Obtiene los permisos activos de un rol.
 */
function obtenerPermisosPorRol(rol) {
  const rolNormalizado =
    normalizarCodigoRol_(rol);

  if (!rolNormalizado) {
    return [];
  }

  const matriz =
    obtenerMatrizPermisos();

  /*
   * El administrador siempre recibe todos los permisos activos de la matriz.
   * Esto evita que una migración de nombres (Administrador -> ADMIN) deje al
   * administrador sin acceso por tener filas antiguas en PermisosRol.
   */
  if (rolNormalizado === 'admin') {
    const todos = [];

    Object.keys(matriz).forEach(
      function(codigoRol) {
        (matriz[codigoRol] || []).forEach(
          function(permiso) {
            if (!todos.includes(permiso)) {
              todos.push(permiso);
            }
          }
        );
      }
    );

    return todos;
  }

  return (
    matriz[rolNormalizado] || []
  );
}

/**
 * Normaliza nombres históricos y nombres visibles al código estable del rol.
 * Las autorizaciones nunca deben depender del texto mostrado en pantalla.
 */
function normalizarCodigoRol_(rol) {
  const valor = normalizarTexto(rol);

  const alias = {
    'administrador': 'admin',
    'administrador del sistema': 'admin',
    'admin': 'admin',
    'equipo de audiovisuales': 'audiovisual',
    'coordinador de audiovisuales': 'audiovisual',
    'audiovisuales': 'audiovisual',
    'audiovisual': 'audiovisual',
    'lider del retiro': 'lider_retiro',
    'lideres del retiro': 'lider_retiro',
    'coordinador general': 'lider_retiro',
    'coordinador general del retiro': 'lider_retiro',
    'lider_retiro': 'lider_retiro',
    'lider de mesa': 'lider_mesa',
    'lideres de mesa': 'lider_mesa',
    'lider_mesa': 'lider_mesa',
    'servidor': 'servidor',
    'servidores': 'servidor',
    'equipo de registro': 'registro',
    'coordinador de registro': 'registro',
    'registro': 'registro',
    'tesoreria': 'tesoreria',
    'campanero': 'campanero'
  };

  return alias[valor] || valor.replace(/\s+/g, '_');
}

/**
 * Valida que un rol exista y esté activo.
 */
function validarRolActivo(rol) {
  const rolNormalizado =
    normalizarCodigoRol_(rol);

  if (!rolNormalizado) {
    throw crearErrorAplicacion(
      'ROL_REQUERIDO',
      'El usuario no tiene un rol configurado.'
    );
  }

  const roles =
    leerHojaComoObjetos(
      HOJAS.ROLES
    );

  const registro =
    roles.find(
      function(item) {
        return (
          normalizarCodigoRol_(
            item.rol
          ) === rolNormalizado
        );
      }
    );

  if (!registro) {
    throw crearErrorAplicacion(
      'ROL_NO_CONFIGURADO',
      'El rol "' +
        rol +
        '" no está configurado.'
    );
  }

  if (
    !convertirBooleano(
      registro.activo
    )
  ) {
    throw crearErrorAplicacion(
      'ROL_INACTIVO',
      'El rol "' +
        rol +
        '" se encuentra inactivo.'
    );
  }

  return registro;
}

/**
 * Normaliza un permiso.
 */
function normalizarPermiso(permiso) {
  return String(
    permiso || ''
  )
    .trim()
    .toUpperCase()
    .replace(/\s+/g, '_');
}

/**
 * Limpia la caché de permisos.
 *
 * Ejecuta esta función después de modificar
 * la hoja PermisosRol.
 */
function limpiarCachePermisos() {
  CacheService
    .getScriptCache()
    .remove(
      CLAVE_CACHE_PERMISOS_ROL
    );

  console.log(
    'Caché de permisos eliminada.'
  );

  return {
    eliminada: true
  };
}

/**
 * Prueba los permisos de un rol.
 */
function probarPermisosAdministrador() {
  const permisos =
    obtenerPermisosPorRol(
      'Administrador'
    );

  console.log(
    JSON.stringify(
      permisos,
      null,
      2
    )
  );
}

/** Valida un permiso exacto o un permiso TODO asociado. */
function tienePermisoSesion(token, permiso) {
  const sesion = obtenerSesion(token);
  const permisos = obtenerPermisosPorRol(sesion.rol);
  const requerido = normalizarPermiso(permiso);
  if (permisos.indexOf(requerido) >= 0) return true;
  const mapaTodo = {
    GESTIONAR_PRESENTACIONES: 'PRESENTACIONES_TODO',
    REPORTAR_PAGO_REGISTRAR: 'REPORTAR_PAGO_TODO'
  };
  return Boolean(mapaTodo[requerido] && permisos.indexOf(mapaTodo[requerido]) >= 0);
}

function validarPermisoSesion(token, permiso, mensaje) {
  const sesion = obtenerSesion(token);
  if (!tienePermisoSesion(token, permiso)) {
    throw crearErrorAplicacion('PERMISO_DENEGADO', mensaje || 'No tiene permisos para realizar esta acción.');
  }
  return sesion;
}
