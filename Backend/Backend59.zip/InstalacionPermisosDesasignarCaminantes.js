/**
 * Entrega 6.26
 *
 * Agrega los permisos:
 * - MESAS_DESASIGNAR_CAMINANTE
 * - HABITACIONES_DESASIGNAR_CAMINANTE
 *
 * Los habilita exclusivamente para:
 * - ADMIN
 * - LIDER_RETIRO
 *
 * Ejecutar una sola vez después de desplegar Backend.
 */
function instalarPermisosDesasignarCaminantes() {
  var libro = obtenerLibro();

  var hoja =
    libro.getSheetByName(
      HOJAS.PERMISOS_ROL
    );

  if (!hoja) {
    throw crearErrorAplicacion(
      'HOJA_PERMISOS_NO_EXISTE',
      'No existe la hoja de permisos por rol.'
    );
  }

  var permisos = [
    'MESAS_DESASIGNAR_CAMINANTE',
    'HABITACIONES_DESASIGNAR_CAMINANTE'
  ];

  var rolesPermitidos = [
    'ADMIN',
    'LIDER_RETIRO'
  ];

  var rolesSistema = [
    'ADMIN',
    'AUDIOVISUAL',
    'LIDER_RETIRO',
    'LIDER_MESA',
    'SERVIDOR',
    'REGISTRO',
    'TESORERIA',
    'CAMPANERO',
    'LOGISTICA',
    'ANGELITOS'
  ];

  var registros =
    leerHojaComoObjetos(
      HOJAS.PERMISOS_ROL
    );

  permisos.forEach(
    function(permiso) {
      rolesSistema.forEach(
        function(rol) {
          var activo =
            rolesPermitidos.indexOf(
              rol
            ) >= 0
              ? 'Sí'
              : 'No';

          var existente =
            registros.find(
              function(item) {
                return (
                  normalizarCodigoRol_(
                    item.rol
                  ) ===
                    normalizarCodigoRol_(
                      rol
                    ) &&
                  normalizarPermiso(
                    item.permiso
                  ) ===
                    permiso
                );
              }
            );

          if (existente) {
            var fila =
              registros.indexOf(
                existente
              ) + 2;

            hoja
              .getRange(
                fila,
                3
              )
              .setValue(
                activo
              );
          } else {
            hoja.appendRow([
              rol,
              permiso,
              activo
            ]);
          }
        }
      );
    }
  );

  limpiarCachePermisos();
  SpreadsheetApp.flush();

  return {
    instalado: true,
    permisos: permisos,
    habilitadosPara:
      rolesPermitidos
  };
}
