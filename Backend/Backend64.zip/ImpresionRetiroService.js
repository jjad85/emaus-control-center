/**
 * Plantillas de impresión: escarapelas y marcación de habitaciones.
 * Las imágenes se guardan en Drive y sus IDs/dimensiones en ScriptProperties.
 */
var CLAVE_PLANTILLA_ESCARAPELA_ = 'EMAUS_PLANTILLA_ESCARAPELA';
var CLAVE_PLANTILLA_HABITACION_ = 'EMAUS_PLANTILLA_HABITACION';
var CLAVE_CARPETA_IMPRESION_ = 'EMAUS_CARPETA_PLANTILLAS_IMPRESION';

function obtenerConfiguracionImpresion(token) {
  var sesion = obtenerSesion(token);
  if (!sesion) throw crearErrorAplicacion('SESION_REQUERIDA','Debe iniciar sesión.');
  var props=PropertiesService.getScriptProperties();
  return {
    escarapela: leerPlantillaImpresion_(props,CLAVE_PLANTILLA_ESCARAPELA_),
    habitacion: leerPlantillaImpresion_(props,CLAVE_PLANTILLA_HABITACION_)
  };
}

function guardarPlantillaImpresion(token,tipo,archivo,anchoCm,altoCm) {
  var sesion=validarPermiso(token,'SISTEMA_CONFIGURAR_PLANTILLAS_IMPRESION');
  tipo=String(tipo||'').toLowerCase();
  if(['escarapela','habitacion'].indexOf(tipo)<0) throw crearErrorAplicacion('TIPO_PLANTILLA_INVALIDO','Tipo de plantilla inválido.');
  var ancho=Number(anchoCm), alto=Number(altoCm);
  if(!(ancho>0&&alto>0&&ancho<=50&&alto<=50)) throw crearErrorAplicacion('DIMENSIONES_INVALIDAS','Indique ancho y alto válidos en centímetros.');
  if(!archivo||!archivo.base64||!/^image\//i.test(String(archivo.tipo||''))) throw crearErrorAplicacion('IMAGEN_REQUERIDA','Seleccione una imagen válida.');

  var bytes=Utilities.base64Decode(String(archivo.base64).replace(/^data:[^;]+;base64,/,''));
  if(bytes.length>8*1024*1024) throw crearErrorAplicacion('IMAGEN_MUY_GRANDE','La imagen no puede superar 8 MB.');
  var carpeta=obtenerCarpetaPlantillasImpresion_();
  var blob=Utilities.newBlob(bytes,archivo.tipo,archivo.nombre||('plantilla-'+tipo));
  var file=carpeta.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);

  var props=PropertiesService.getScriptProperties();
  var clave=tipo==='escarapela'?CLAVE_PLANTILLA_ESCARAPELA_:CLAVE_PLANTILLA_HABITACION_;
  var anterior=leerPlantillaImpresion_(props,clave);
  var dato={fileId:file.getId(),nombre:file.getName(),tipo:archivo.tipo,anchoCm:ancho,altoCm:alto,actualizado:new Date().toISOString()};
  props.setProperty(clave,JSON.stringify(dato));
  if(anterior.fileId){try{DriveApp.getFileById(anterior.fileId).setTrashed(true);}catch(e){}}

  if(typeof registrarAuditoria==='function') registrarAuditoria({
    usuario:sesion.usuario||'',nombre:sesion.nombre||'',rol:sesion.rol||'',
    accion:'CONFIGURAR_PLANTILLA_IMPRESION',entidad:'Sistema',idRegistro:tipo,resultado:'EXITOSO',
    detalle:JSON.stringify({tipo:tipo,anchoCm:ancho,altoCm:alto,nombre:dato.nombre}),
    datosAntes:anterior,datosDespues:dato
  });
  return leerPlantillaImpresion_(props,clave);
}

function obtenerDatosGeneracionImpresion(token) {
  validarPermiso(token,'SISTEMA_GENERAR_ESCARAPELAS_HABITACIONES');
  var caminantes=obtenerCaminantes({}).map(function(c){return {
    id:c.id||'',nombre:c.nombre||c.nombreCompleto||'',mesa:c.mesa||'',habitacion:c.habitacion||''
  };});
  var servidores=obtenerServidores({}).filter(function(s){return Boolean(s.activo);});
  var habitaciones=obtenerHabitaciones(obtenerCaminantes({}),servidores).map(function(h){return {
    id:h.id||h.habitacion||'',habitacion:h.habitacion||h.nombre||h.id||'',
    personas:(h.personas||h.personasAsignadas||[]).map(function(p){return {nombre:p.nombre||'',tipoPersona:p.tipoPersona||''};})
  };});
  return {caminantes:caminantes,habitaciones:habitaciones};
}

function obtenerImagenPlantillaImpresion(token,tipo) {
  validarPermiso(token,'SISTEMA_GENERAR_ESCARAPELAS_HABITACIONES');
  tipo=String(tipo||'').toLowerCase();
  var props=PropertiesService.getScriptProperties();
  var dato=leerPlantillaImpresion_(props,tipo==='escarapela'?CLAVE_PLANTILLA_ESCARAPELA_:CLAVE_PLANTILLA_HABITACION_);
  if(!dato.fileId) throw crearErrorAplicacion('PLANTILLA_NO_CONFIGURADA','No existe plantilla configurada.');
  var blob=DriveApp.getFileById(dato.fileId).getBlob();
  return {base64:'data:'+blob.getContentType()+';base64,'+Utilities.base64Encode(blob.getBytes()),anchoCm:dato.anchoCm,altoCm:dato.altoCm,nombre:dato.nombre};
}

function leerPlantillaImpresion_(props,clave){
  var raw=props.getProperty(clave); if(!raw)return {fileId:'',nombre:'',tipo:'',anchoCm:'',altoCm:'',actualizado:''};
  try{return JSON.parse(raw);}catch(e){return {fileId:'',nombre:'',tipo:'',anchoCm:'',altoCm:'',actualizado:''};}
}
function obtenerCarpetaPlantillasImpresion_(){
  var props=PropertiesService.getScriptProperties(),id=props.getProperty(CLAVE_CARPETA_IMPRESION_);
  if(id){try{return DriveApp.getFolderById(id);}catch(e){}}
  var f=DriveApp.createFolder('Plantillas impresión Emaús');props.setProperty(CLAVE_CARPETA_IMPRESION_,f.getId());return f;
}
