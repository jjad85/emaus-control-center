import { emitirSesionExpirada } from '../auth/sessionEvents';
import { administrarGet, invalidarCacheApi } from './requestManager';

const baseURL = import.meta.env.VITE_APPS_SCRIPT_URL;
if (!baseURL) console.warn('Falta configurar VITE_APPS_SCRIPT_URL');

const EVENTO_CARGA_INICIO = 'emaus:api-loading-start';
const EVENTO_CARGA_FIN = 'emaus:api-loading-end';
const CODIGOS_SESION_INVALIDA = new Set([
  'SESION_EXPIRADA', 'SESION_REQUERIDA', 'SESION_INVALIDA',
  'SESION_REVOCADA', 'TOKEN_EXPIRADO', 'TOKEN_INVALIDO',
]);

function emitirCarga(nombreEvento) {
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(nombreEvento));
}

function obtenerErrorApi(payload) {
  const errorApi = payload?.errores?.[0];
  return {
    codigo: errorApi?.codigo || '',
    detalle: errorApi?.detalle || payload?.mensaje || 'Error de API',
  };
}

function procesarRespuesta(payload) {
  if (!payload?.ok) {
    const errorApi = obtenerErrorApi(payload);
    if (CODIGOS_SESION_INVALIDA.has(errorApi.codigo)) {
      emitirSesionExpirada(errorApi.detalle);
    }
    const error = new Error(errorApi.detalle);
    error.codigo = errorApi.codigo;
    throw error;
  }
  return payload;
}

async function leerRespuesta(response) {
  const texto = await response.text();
  let payload;
  try {
    payload = JSON.parse(texto);
  } catch {
    const error = new Error(
      response.ok
        ? 'Google Apps Script devolvió una respuesta no válida.'
        : `Google Apps Script respondió temporalmente con estado ${response.status}. Conservamos tu sesión; vuelve a intentar.`
    );
    error.estadoHttp = response.status;
    throw error;
  }
  if (!response.ok) {
    const error = new Error(payload?.mensaje || `Error HTTP ${response.status}`);
    error.estadoHttp = response.status;
    throw error;
  }
  return procesarRespuesta(payload);
}

async function fetchConTimeout(url, options = {}, timeout = 30000) {
  const controlador = new AbortController();
  const temporizador = window.setTimeout(() => controlador.abort(), timeout);
  try {
    return await fetch(url, {
      ...options,
      signal: controlador.signal,
      redirect: 'follow',
      cache: 'no-store',
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      const timeoutError = new Error('La operación tardó más de lo esperado. Vuelve a intentarlo.');
      timeoutError.codigo = 'TIMEOUT';
      throw timeoutError;
    }
    throw new Error('No fue posible completar la comunicación con Google Apps Script. Vuelve a intentarlo.');
  } finally {
    window.clearTimeout(temporizador);
  }
}

function construirUrl(recurso, params = {}) {
  const url = new URL(baseURL);
  url.searchParams.set('recurso', recurso);
  Object.entries(params).forEach(([clave, valor]) => {
    if (valor !== undefined && valor !== null && valor !== '') {
      url.searchParams.set(clave, String(valor));
    }
  });
  return url.toString();
}

export async function getResource(recurso, params = {}) {
  emitirCarga(EVENTO_CARGA_INICIO);
  try {
    return await administrarGet({
      recurso,
      params,
      ejecutar: async () => {
        const response = await fetchConTimeout(construirUrl(recurso, params), {
          method: 'GET',
          headers: { Accept: 'application/json' },
        });
        return leerRespuesta(response);
      },
    });
  } finally {
    emitirCarga(EVENTO_CARGA_FIN);
  }
}

export async function postAction(accion, payload = {}, options = {}) {
  emitirCarga(EVENTO_CARGA_INICIO);
  try {
    const response = await fetchConTimeout(baseURL, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'text/plain;charset=UTF-8',
      },
      body: JSON.stringify({ accion, ...payload }),
    }, options.timeout ?? 30000);
    const resultado = await leerRespuesta(response);
    invalidarCacheApi();
    return resultado;
  } finally {
    emitirCarga(EVENTO_CARGA_FIN);
  }
}

export default { get: getResource, post: postAction };
