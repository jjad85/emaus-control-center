import axios from 'axios';
import {
  emitirSesionExpirada,
} from '../auth/sessionEvents';

const baseURL =
  import.meta.env.VITE_APPS_SCRIPT_URL;

if (!baseURL) {
  console.warn(
    'Falta configurar VITE_APPS_SCRIPT_URL'
  );
}


const EVENTO_CARGA_INICIO = 'emaus:api-loading-start';
const EVENTO_CARGA_FIN = 'emaus:api-loading-end';

function emitirCarga(nombreEvento) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(nombreEvento));
  }
}

const apiClient = axios.create({
  baseURL,
  timeout: 30000,
  headers: {
    Accept: 'application/json',
  },
});

function obtenerErrorApi(
  payload
) {
  const errorApi =
    payload?.errores?.[0];

  return {
    codigo:
      errorApi?.codigo || '',

    detalle:
      errorApi?.detalle ||
      payload?.mensaje ||
      'Error de API',
  };
}

function procesarRespuesta(
  payload
) {
  if (!payload?.ok) {
    const errorApi =
      obtenerErrorApi(
        payload
      );

    if (
      errorApi.codigo ===
        'SESION_EXPIRADA' ||
      errorApi.codigo ===
        'SESION_REQUERIDA' ||
      errorApi.codigo ===
        'SESION_INVALIDA' ||
      errorApi.codigo ===
        'SESION_REVOCADA'
    ) {
      emitirSesionExpirada(
        errorApi.detalle
      );
    }

    const error =
      new Error(
        errorApi.detalle
      );

    error.codigo =
      errorApi.codigo;

    throw error;
  }

  return payload;
}

function procesarError(error) {
  if (error?.codigo) {
    throw error;
  }

  const payload =
    error?.response?.data;

  if (payload) {
    return procesarRespuesta(
      payload
    );
  }

  if (
    error?.code === 'ECONNABORTED' ||
    String(error?.message || '')
      .toLowerCase()
      .includes('timeout')
  ) {
    throw new Error(
      'La operación tardó más de lo esperado. Verifica si el archivo quedó registrado antes de volver a cargarlo.'
    );
  }

  const mensaje = String(error?.message || '');
  if (mensaje.toLowerCase().includes('network error')) {
    throw new Error(
      'No fue posible completar la comunicación con Google Apps Script. Verifica que la implementación esté actualizada y vuelve a intentar.'
    );
  }

  const estado =
    Number(
      error?.response?.status || 0
    );

  const errorFinal =
    new Error(
      estado
        ? `Google Apps Script respondió temporalmente con estado ${estado}. Conservamos tu sesión; vuelve a intentar.`
        : (
            mensaje ||
            'No fue posible conectar con la API'
          )
    );

  errorFinal.estadoHttp =
    estado;

  throw errorFinal;
}


export async function getResource(
  recurso,
  params = {}
) {
  emitirCarga(EVENTO_CARGA_INICIO);
  try {
    const response =
      await apiClient.get('', {
        params: {
          recurso,
          ...params,
          t: Date.now(),
        },
      });

    return procesarRespuesta(
      response.data
    );
  } catch (error) {
    return procesarError(
      error
    );
  } finally {
    emitirCarga(EVENTO_CARGA_FIN);
  }
}

export async function postAction(
  accion,
  payload = {},
  options = {}
) {
  emitirCarga(EVENTO_CARGA_INICIO);
  try {
    const body =
      JSON.stringify({
        accion,
        ...payload,
      });

    const response =
      await axios.post(
        baseURL,
        body,
        {
          timeout:
            options.timeout ??
            30000,

          // No se registra onUploadProgress. En llamadas directas a Google
          // Apps Script, agregar un listener de progreso al XMLHttpRequest
          // obliga al navegador a enviar una petición OPTIONS (preflight).
          // Apps Script no responde ese preflight con CORS y termina en
          // "Network Error", aunque el archivo pueda haberse guardado.

          headers: {
            Accept:
              'application/json',

            'Content-Type':
              'text/plain;charset=UTF-8',
          },
        }
      );

    return procesarRespuesta(
      response.data
    );
  } catch (error) {
    return procesarError(
      error
    );
  } finally {
    emitirCarga(EVENTO_CARGA_FIN);
  }
}

export default apiClient;
