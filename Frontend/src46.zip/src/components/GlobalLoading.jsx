import {
  Backdrop,
  Box,
  CircularProgress,
  Paper,
  Stack,
  Typography,
} from '@mui/material';
import { useEffect, useRef, useState } from 'react';

const EVENTO_INICIO = 'emaus:api-loading-start';
const EVENTO_FIN = 'emaus:api-loading-end';

export default function GlobalLoading() {
  const [cantidad, setCantidad] = useState(0);
  const [visible, setVisible] = useState(false);
  const temporizador = useRef(null);

  useEffect(() => {
    function iniciar() {
      setCantidad((actual) => actual + 1);
    }

    function finalizar() {
      setCantidad((actual) => Math.max(0, actual - 1));
    }

    window.addEventListener(EVENTO_INICIO, iniciar);
    window.addEventListener(EVENTO_FIN, finalizar);

    return () => {
      window.removeEventListener(EVENTO_INICIO, iniciar);
      window.removeEventListener(EVENTO_FIN, finalizar);
      window.clearTimeout(temporizador.current);
    };
  }, []);

  useEffect(() => {
    window.clearTimeout(temporizador.current);

    if (cantidad > 0) {
      temporizador.current = window.setTimeout(() => setVisible(true), 250);
    } else {
      setVisible(false);
    }

    return () => window.clearTimeout(temporizador.current);
  }, [cantidad]);

  return (
    <Backdrop
      open={visible}
      sx={{
        zIndex: (theme) => theme.zIndex.modal + 20,
        bgcolor: 'rgba(7, 31, 27, .48)',
        backdropFilter: 'blur(4px)',
      }}
    >
      <Paper
        elevation={14}
        sx={{
          px: 3.5,
          py: 2.5,
          borderRadius: 4,
          minWidth: 280,
          bgcolor: 'rgba(255,255,255,.96)',
        }}
      >
        <Stack direction="row" spacing={2} alignItems="center">
          <Box sx={{ display: 'grid', placeItems: 'center' }}>
            <CircularProgress size={34} thickness={4.5} />
          </Box>
          <Box>
            <Typography fontWeight={950}>Procesando solicitud</Typography>
            <Typography variant="body2" color="text.secondary">
              Espera un momento. No cierres esta ventana.
            </Typography>
          </Box>
        </Stack>
      </Paper>
    </Backdrop>
  );
}
