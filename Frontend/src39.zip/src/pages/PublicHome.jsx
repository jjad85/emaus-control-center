import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Container,
  Grid,
  Stack,
  Typography,
} from '@mui/material';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import AutoAwesomeRounded from '@mui/icons-material/AutoAwesomeRounded';
import Diversity3Rounded from '@mui/icons-material/Diversity3Rounded';
import ExpandMoreRounded from '@mui/icons-material/ExpandMoreRounded';
import FavoriteRounded from '@mui/icons-material/FavoriteRounded';
import HowToRegRounded from '@mui/icons-material/HowToRegRounded';
import LoginRounded from '@mui/icons-material/LoginRounded';
import PaymentsRounded from '@mui/icons-material/PaymentsRounded';
import VolunteerActivismRounded from '@mui/icons-material/VolunteerActivismRounded';

import { useAuth } from '../auth/AuthContext';
import LoginDialog from '../auth/LoginDialog';
import { useApi } from '../hooks/useApi';
import { obtenerPortalPublico } from '../api/publicApi';
import PublicNavbar from '../components/publico/PublicNavbar';
import PublicFooter from '../components/publico/PublicFooter';
import '../styles/portalPublico.css';

const pilares = [
  {
    icono: <FavoriteRounded />,
    titulo: 'Encuentro',
    texto: 'Un espacio para detenerse, escuchar y permitir que Dios vuelva a caminar a nuestro lado.',
  },
  {
    icono: <Diversity3Rounded />,
    titulo: 'Comunidad',
    texto: 'La experiencia no termina el domingo. Continúa en una comunidad que acompaña y sostiene.',
  },
  {
    icono: <VolunteerActivismRounded />,
    titulo: 'Servicio',
    texto: 'Lo recibido se transforma en disponibilidad, fraternidad y servicio a quienes vienen detrás.',
  },
];

const pasos = [
  ['01', 'La invitación', 'Alguien de la comunidad te invita a abrir un espacio distinto en medio de la rutina.'],
  ['02', 'El retiro', 'Tres días para escuchar, compartir y vivir un encuentro personal, sin revelar aquello que hace única la experiencia.'],
  ['03', 'La comunidad', 'Después del retiro comienza un camino de acompañamiento, oración y crecimiento fraterno.'],
  ['04', 'El servicio', 'Cada persona puede poner sus dones al servicio de otros y ayudar a mantener viva la comunidad.'],
];

const preguntas = [
  ['¿Necesito pertenecer a la parroquia?', 'No es necesario. Emaús recibe a personas que desean vivir la experiencia y abrir un espacio para su vida espiritual.'],
  ['¿Debo tener experiencia previa en grupos de Iglesia?', 'No. El retiro está pensado también para quienes no participan actualmente en una comunidad o desean volver a acercarse.'],
  ['¿Cuánto dura el retiro?', 'Se vive durante un fin de semana completo. La información precisa de horarios y logística la entrega el equipo organizador.'],
  ['¿Qué debo llevar?', 'Antes del retiro recibirás indicaciones claras sobre ropa, elementos personales y recomendaciones prácticas.'],
  ['¿Cómo puedo recibir más información?', 'Puedes iniciar el proceso de inscripción desde esta página o comunicarte con una persona de la comunidad que te haya invitado.'],
];

export default function PublicHome() {
  const navigate = useNavigate();
  const { autenticado, solicitarAutenticacion } = useAuth();
  const portalApi = useApi(() => obtenerPortalPublico(), []);

  useEffect(() => {
    if (autenticado) navigate('/dashboard', { replace: true });
  }, [autenticado, navigate]);

  const portal = portalApi.data || {};
  const registroActivo = portal.registroActivo !== false;
  const titulo = portal.titulo || 'Retiro de Emaús';
  const subtitulo = portal.subtitulo || 'Una experiencia de encuentro, fe y transformación.';
  const textoAcceso = portal.textoBotonLogin || 'Centro de Control';

  return (
    <Box className="public-page">
      <PublicNavbar onLogin={() => solicitarAutenticacion()} />

      <Box component="main">
        <Box id="inicio" component="section" className="public-hero">
          <Box className="public-orb public-orb-one" />
          <Box className="public-orb public-orb-two" />
          <Container maxWidth="xl" sx={{ py: { xs: 12, md: 16 } }}>
            <Box maxWidth={1000}>
              <Box className="public-kicker">
                <AutoAwesomeRounded fontSize="small" />
                PARROQUIA SANTA TERESITA
              </Box>
              <Typography component="h1" className="public-hero-title">
                Caminemos juntos hacia un <em>nuevo encuentro.</em>
              </Typography>
              <Typography className="public-hero-copy">
                {titulo}. {subtitulo} Un camino para detenernos, reconocernos y descubrir que no estamos solos.
              </Typography>

              <Box className="public-retreat-quick-info">
                <span>PRÓXIMO RETIRO</span>
                <strong>11 · 12 · 13 de septiembre de 2026</strong>
              </Box>

              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} mt={2.5} alignItems={{ sm: 'center' }}>
                <Button
                  className="public-primary-cta"
                  startIcon={<HowToRegRounded />}
                  endIcon={<ArrowForwardRounded />}
                  disabled={!registroActivo}
                  onClick={() => navigate('/registro')}
                >
                  {registroActivo ? portal.textoBotonRegistro || 'Inscribirme al retiro' : 'Inscripciones cerradas'}
                </Button>
                <Button
                  className="public-secondary-cta"
                  variant="outlined"
                  onClick={() => document.getElementById('que-es-emaus')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Conoce Emaús
                </Button>
              </Stack>
              <Typography className="public-hero-action-note">
                La inscripción está disponible desde el primer momento. El acceso al Centro de Control permanece en el menú superior.
              </Typography>

              <Box className="public-scripture-card">
                <Typography fontStyle="italic" lineHeight={1.65}>
                  “¿No ardía nuestro corazón mientras nos hablaba por el camino?”
                </Typography>
                <Typography variant="caption" color="inherit">Lucas 24, 32</Typography>
              </Box>
            </Box>
          </Container>
        </Box>

        <Box id="que-es-emaus" component="section" className="public-section">
          <Container maxWidth="xl">
            <Typography className="public-section-label">UN CAMINO DE ENCUENTRO</Typography>
            <Typography component="h2" className="public-section-title">
              Emaús no es solo un retiro. Es el comienzo de un camino.
            </Typography>
            <Typography className="public-section-copy">
              Inspirado en el encuentro de Jesús resucitado con los discípulos que caminaban hacia Emaús, este espacio invita a mirar la propia historia con calma, fe y esperanza.
            </Typography>

            <Grid container spacing={2.5} mt={3}>
              {pilares.map((pilar) => (
                <Grid key={pilar.titulo} size={{ xs: 12, md: 4 }}>
                  <Box className="public-glass-card">
                    <Box className="public-icon-shell">{pilar.icono}</Box>
                    <Typography variant="h5" fontWeight={950} mt={3}>{pilar.titulo}</Typography>
                    <Typography color="text.secondary" mt={1.4} lineHeight={1.75}>{pilar.texto}</Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Container>
        </Box>

        <Box id="comunidad" component="section" className="public-section public-section-dark">
          <Container maxWidth="xl">
            <Grid container spacing={7} alignItems="center">
              <Grid size={{ xs: 12, md: 6 }}>
                <Typography className="public-section-label">NO CAMINAMOS SOLOS</Typography>
                <Typography component="h2" className="public-section-title">
                  Una comunidad que acompaña antes, durante y después.
                </Typography>
                <Typography className="public-section-copy">
                  Somos hombres con historias distintas que comparten una misma certeza: la fe se fortalece cuando se vive en comunidad, con espacios de oración, conversación y servicio.
                </Typography>
                <Grid container spacing={2} mt={3}>
                  <Grid size={{ xs: 12, sm: 6 }}><Box className="public-stat-card"><Typography variant="h4" fontWeight={950}>Fe</Typography><Typography color="rgba(255,255,255,.58)">Un camino personal y compartido.</Typography></Box></Grid>
                  <Grid size={{ xs: 12, sm: 6 }}><Box className="public-stat-card"><Typography variant="h4" fontWeight={950}>Servicio</Typography><Typography color="rgba(255,255,255,.58)">Dones puestos al servicio de otros.</Typography></Box></Grid>
                </Grid>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <Box className="public-timeline">
                  {pasos.map(([numero, tituloPaso, texto]) => (
                    <Box className="public-timeline-item" key={numero}>
                      <Box className="public-timeline-number">{numero}</Box>
                      <Box pt={0.5}>
                        <Typography variant="h6" fontWeight={950}>{tituloPaso}</Typography>
                        <Typography mt={0.7} color="rgba(255,255,255,.6)" lineHeight={1.7}>{texto}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>

        <Box id="proximo-retiro" component="section" className="public-section">
          <Container maxWidth="lg">
            <Box className="public-retiro-panel">
              <Grid container>
                <Grid size={{ xs: 12, md: 5 }} className="public-date-block">
                  <Typography className="public-section-label">PRÓXIMO RETIRO</Typography>
                  <Typography variant="h2" fontWeight={950} mt={2} letterSpacing={-2}>11 · 12 · 13</Typography>
                  <Typography variant="h5" fontWeight={850}>Septiembre de 2026</Typography>
                  <Typography mt={2} color="text.secondary">Parroquia Santa Teresita</Typography>
                </Grid>
                <Grid size={{ xs: 12, md: 7 }} sx={{ p: { xs: 3.5, md: 5 }, bgcolor: 'white' }}>
                  <Typography variant="h4" fontWeight={950}>Da el primer paso.</Typography>
                  <Typography mt={1.5} color="text.secondary" lineHeight={1.75}>
                    El retiro está pensado para vivirlo, no para explicarlo por completo. Inicia tu inscripción y el equipo organizador te acompañará con toda la información necesaria.
                  </Typography>
                  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.3} mt={3}>
                    <Button
                      variant="contained"
                      disabled={!registroActivo}
                      startIcon={<HowToRegRounded />}
                      onClick={() => navigate('/registro')}
                      sx={{ borderRadius: 999, px: 3, py: 1.35, textTransform: 'none', fontWeight: 900 }}
                    >
                      {registroActivo ? portal.textoBotonRegistro || 'Quiero inscribirme' : 'Inscripciones cerradas'}
                    </Button>
                    <Button
                      variant="outlined"
                      startIcon={<PaymentsRounded />}
                      onClick={() => navigate('/reportar-pago')}
                      sx={{ borderRadius: 999, px: 3, py: 1.35, textTransform: 'none', fontWeight: 900 }}
                    >
                      Reportar pago
                    </Button>
                  </Stack>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </Box>

        <Box id="preguntas" component="section" className="public-section" sx={{ pt: 2 }}>
          <Container maxWidth="md">
            <Typography className="public-section-label" textAlign="center">PREGUNTAS FRECUENTES</Typography>
            <Typography component="h2" className="public-section-title" textAlign="center" mx="auto">
              Lo esencial antes de comenzar.
            </Typography>
            <Box className="public-faq" mt={5}>
              {preguntas.map(([pregunta, respuesta]) => (
                <Accordion key={pregunta} disableGutters>
                  <AccordionSummary expandIcon={<ExpandMoreRounded />}>
                    <Typography fontWeight={900}>{pregunta}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography color="text.secondary" lineHeight={1.75}>{respuesta}</Typography>
                  </AccordionDetails>
                </Accordion>
              ))}
            </Box>
          </Container>
        </Box>
      </Box>

      {registroActivo && (
        <Button
          className="public-mobile-register"
          startIcon={<HowToRegRounded />}
          onClick={() => navigate('/registro')}
        >
          Inscribirme al retiro
        </Button>
      )}

      <PublicFooter />
      <LoginDialog />
    </Box>
  );
}
