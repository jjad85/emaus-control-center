import { postAction } from './apiClient';

const TIMEOUT_CARGA_ARCHIVO = 180000;

export async function obtenerMiTemaAsignado(token) {
  const response = await postAction(
    'obtenerMiTemaAsignado',
    { token }
  );

  return response.datos;
}


export async function obtenerHistorialGeneralMiTema(token, temaId) {
  const response = await postAction(
    'obtenerHistorialGeneralMiTema',
    { token, temaId }
  );

  return response.datos;
}

export async function subirVersionTema(
  token,
  temaId,
  archivo,
  comentario = ''
) {
  const response = await postAction(
    'subirVersionTema',
    {
      token,
      temaId,
      archivo,
      comentario,
    },
    {
      timeout: TIMEOUT_CARGA_ARCHIVO,
    }
  );

  return response.datos;
}

export async function actualizarPreferenciasMiTema(
  token,
  temaId,
  datos
) {
  const response = await postAction(
    'actualizarPreferenciasMiTema',
    { token, temaId, datos }
  );

  return response.datos;
}

export async function subirMusicaTema(
  token,
  temaId,
  archivo,
  observaciones = ''
) {
  const response = await postAction(
    'subirMusicaTema',
    {
      token,
      temaId,
      archivo,
      observaciones,
    },
    {
      timeout: TIMEOUT_CARGA_ARCHIVO,
    }
  );

  return response.datos;
}

export async function guardarRecursosMiTema(token, temaId, datos) {
  const response = await postAction(
    'guardarRecursosMiTema',
    { token, temaId, datos }
  );

  return response.datos;
}

export function archivoABase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () =>
      resolve({
        nombre: file.name,
        tipo: file.type,
        base64: reader.result,
      });

    reader.onerror = () =>
      reject(
        new Error(
          'No fue posible leer el archivo.'
        )
      );

    reader.readAsDataURL(file);
  });
}
